﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Telephony.Exceptions;
using Telephony.Interfaces;

namespace Telephony.Models
{
    public class Smartphone : IBrowsable, ICallable
    {
        public string Browse(string url)
        {
            // Ако някой символ е цифра, хвърли грешка
            if (url.Any(x => char.IsDigit(x)))
            {
                throw new InvalidUrlException();
            }

            return $"Browsing: {url}!";
        }

        public string Call(string phoneNumber)
        {
            // Ако всички символи не са цифри, хвърли грешка
            if (!phoneNumber.All(x => char.IsDigit(x)))
            {
                throw new InvalidPhoneNumberException();
            }

            return $"Calling... {phoneNumber}";
        }
    }
}
