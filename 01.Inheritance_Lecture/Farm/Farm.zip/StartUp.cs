﻿using System;

namespace Farm
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Dog doggy = new Dog();
            doggy.Eat();
            doggy.Bark();

            Cat pissi = new Cat();
            pissi.Eat();
            pissi.Meow();
        }
    }
}
