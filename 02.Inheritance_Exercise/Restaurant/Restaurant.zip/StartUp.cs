﻿using System;

namespace Restaurant
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Coffee coffee = new Coffee("LA", 5.5);
            Console.WriteLine();
        }
    }
}
