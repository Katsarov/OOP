﻿using System;

namespace Zoo
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //Animal newAnimal = new Snake("Penka");
            //Console.WriteLine(newAnimal);

            //Animal animal;

            Animal animalOne = new Animal("Ani");
            Animal animalTwo = new Reptile("Repo");
            Animal animalThree = new Mammal("Mami");
            Animal animalFour = new Lizard("Lizi");
            Animal animalFive = new Snake("Sisi");
            Animal animalSix = new Gorilla("Geri");
            Animal animalSeven = new Bear("Bari");

            Console.WriteLine(animalFour.Name);
            Console.WriteLine(animalFour.GetType());
        }
    }
}
